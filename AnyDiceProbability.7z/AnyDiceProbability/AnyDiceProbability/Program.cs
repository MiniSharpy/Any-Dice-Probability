﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnyDiceProbability
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculateAllProbability calculateAllProbability = new CalculateAllProbability();

            for (int i = 1; i < 3; i++)
            {
                for (int j = 1; j < 3; j++)
                {
                    Console.WriteLine(i + j);
                }
            }
            Console.WriteLine();

            Repeat();

            Console.Read();
        }

        private static void Repeat(int depth = 0, int number = 0)
        {        
            depth += 1;
            for (int i = 1; i < 3; i++)
            {
                number += i;
                if (depth < 2)
                {
                    Repeat(depth, number);
                }
                else
                {
                    Console.WriteLine(number);
                }
            }
        }

        private static void WriteList<T>(List<T> list)
        {
            foreach (var item in list)
            {
                Console.Write(item + " ");
            }
            Console.Write("\n");
        }
    }
}
